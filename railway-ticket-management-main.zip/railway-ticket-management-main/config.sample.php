<?php

$RazorpayKeyId = '<Enter your key id>';
$RazorpayKeySecret = '<Enter your key secret>';
$displayCurrency = '<Enter your display currency here>';
